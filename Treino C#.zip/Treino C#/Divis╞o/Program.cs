﻿using System;
using System.Threading;

class Program
{
    static void Main()
    {
        while (true)
        {
            Console.Write("Digite o primeiro número: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Digite o segundo número: ");
            double b = double.Parse(Console.ReadLine());

            if (b != 0)
            {
                Console.WriteLine("Divisão: " + (a / b));
                break; // encerra o loop se a divisão for possível
            }
            else
            {
                Console.WriteLine("Não é possível dividir por zero! Tente de novo em 3 segundos...");
                Thread.Sleep(3000); // espera 3 segundos antes de repetir
                Console.Clear(); // limpa a tela para uma melhor experiência
            }
        }
    }
}