﻿using System;

class Program{
    static void Main()
    {
      
            Console.Write("Digite a base: ");
            double a = double.Parse(Console.ReadLine());
            Console.Write("Digite o expoente: ");
            double b = double.Parse(Console.ReadLine());

            double resultado = Math.Pow(a, b);
            Console.WriteLine("Potência: " + resultado);   
    }
}
